# Tasks

## Task 1: Create a Simple Webpage with a Heading, Paragraph, and a List

**Prompt Example:**

"Create a webpage with a heading that says 'My First Webpage', a paragraph about your favorite hobby, and a list of 3 things you enjoy about it."

## Task 2: Add Basic Semantic Elements (like `<header>`, `<section>`, `<footer>`) to the Webpage

**Prompt Example:**

"Modify your previous webpage by adding a header with your name, a section with a brief description of yourself, and a footer with your contact information."
